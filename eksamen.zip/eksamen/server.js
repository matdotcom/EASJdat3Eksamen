// til at "åbne serveren"
var app = require('express')();//Sætter express til at være app.
var http = require('http').Server(app);//Den der åbner serveren.
bodyParser = require('body-parser'); //Når der skal arbejdes med JSON objekter Parser det om til læselige json objekter fra servere.
var mysql = require('mysql'); // mySQL
var getbitcoin = require('bitcoin') // bitcoin modul
const fetch = require("node-fetch");
var cors = require('cors')
getbitcoin.bitcoinUSD();


app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(cors());


// Get request : henter index.html
app.get('/',function(req, res){
    res.sendFile(__dirname + '/index.html');
})
// mysql connection 
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "password"
  });

    // Get request 2 : Henter brugere
app.get('/hent', function(req,res){
        console.log("Connected!"); // Logger hvis der ingen error forekommer og du er connected.
        con.query("use CryptoBank;", function (err, result) { //Bruger schema fra mysql db.
            if (err) throw err; // Logger hvis der er en error, thrower errors.
            console.log("Query godtaget!"); // Logger hvis connected.
          });
        con.query("SELECT * FROM CryptoBank.Konto inner join CryptoBank.kunde ON KundeID = Kunde.ID", function (err, result) { //Vælg alt fra table "brugere"
          if (err) throw err;//Tjekker for fejl, throw errors.
          console.log(result); //Logger alt der er selected.
        res.send(result); //Det er det den sender når man går ind på /hent
        });
        // bedre error handling til node så det ikke crasher. Try/catch virker ikke. 
        process.on('uncaughtException', function (err) {
          console.error(err);
          console.log("Node NOT Exiting...");
        });
})
// post request til insert i CryptoBank.Konto table
app.post('/opret', function(req, res){
        console.log("Connected!"); // Logger hvis connected.
        con.query("use CryptoBank;", function (err, result) { //Brug schema fra mysql db.
            if (err) throw err; //Tjekker for fejl, throw errors.
            console.log("connected"); // Logger hvis connected.
          });
          con.query("insert `CryptoBank`.`Konto`(`KundeID`, `kontonummer`, `valutatype`, `saldo`) values('"+req.body.kundeID+"', '"+req.body.kontonummer+"', '"+req.body.valutatype+"', '"+req.body.saldo+"');", 
          function (err, result) { 
          if (err) throw err;//Tjekker for fejl, throw errors.
          console.log("selected *"); //Logger alt der er selected.
        res.send("Sucess!"); //Det er det den sender når man går ind på /opret og at post requestet var succesfuldt
        });
        // bedre error handling til node så det ikke crasher. Try/catch virker ikke. 
        process.on('uncaughtException', function (err) {
          console.error(err);
          console.log("Node NOT Exiting...");
        });
})

// dummy metode til transaktion
app.post('/overfoer', function(req, res){
  console.log("Connected!"); // Logger hvis connected.
  con.query("use CryptoBank;", function (err, result) { //Brug schema fra mysql db.
      if (err) throw err; //Tjekker for fejl, throw errors.
      console.log("connected"); // Logger hvis connected.
    });
    // denne query skal så tage det du vil overføre, som du indtaster i en form
    con.query("insert `CryptoBank`.`Konto`(`KundeID`, `kontonummer`, `valutatype`, `saldo`) values('"+req.body.kundeID+"', '"+req.body.kontonummer+"', '"+req.body.valutatype+"', '"+req.body.saldo+"');", 
    function (err, result) { 
    if (err) throw err;//Tjekker for fejl, throw errors.
    console.log("selected *"); //Logger alt der er selected.
  res.send("Sucess!"); //Det er det den sender når man går ind på /opret og at post requestet var succesfuldt
  });
  // bedre error handling til node så det ikke crasher. Try/catch virker ikke. 
  process.on('uncaughtException', function (err) {
    console.error(err);
    console.log("Node NOT Exiting...");
  });
})




// hoster serveren på localhost med port 3000
  http.listen(3000, function(){
    console.log('listening on *:3000');
  });