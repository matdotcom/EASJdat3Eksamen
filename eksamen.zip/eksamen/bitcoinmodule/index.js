// da node ikke understøtter fetch endnu, requirer jeg node-fetch til mit modul. Så for at køre modulet, skal du have installeret
// node-fetch.
const fetch = require("node-fetch");
function getbitcoin(){
    fetch('https://blockchain.info/ticker')
    .catch(err=> console.error(err))
    //konverterer responset til json 
.then(res => res.json())
//logger vores response fra request.
.then(json => console.log(json));
}

exports.bitcoinUSD = getbitcoin;



